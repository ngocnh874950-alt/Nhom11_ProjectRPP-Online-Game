import socket
import threading
import random

HOST = "127.0.0.1"
PORT = 9999

clients = []

def check_result(client, server):
    if client == server:
        return "HÒA"
    if (client == "Rock" and server == "Scissors") or \
       (client == "Paper" and server == "Rock") or \
       (client == "Scissors" and server == "Paper"):
        return "BẠN THẮNG"
    return "BẠN THUA"

def handle_client(conn, addr):
    print(f"[CLIENT CONNECTED] {addr}")
    conn.sendall("CONNECTED".encode())

    while True:
        try:
            data = conn.recv(1024).decode()
            if not data:
                break

            user_choice = data
            server_choice = random.choice(["Rock", "Paper", "Scissors"])
            result = check_result(user_choice, server_choice)

            message = f"{user_choice},{server_choice},{result}"
            conn.sendall(message.encode())

        except:
            break

    conn.close()
    print(f"[CLIENT DISCONNECTED] {addr}")

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen()

print("🎮 RPP Server running...")

while True:
    conn, addr = server.accept()
    threading.Thread(
        target=handle_client,
        args=(conn, addr),
        daemon=True
    ).start()
