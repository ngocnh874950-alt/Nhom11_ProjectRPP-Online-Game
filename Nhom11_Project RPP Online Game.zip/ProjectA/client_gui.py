import tkinter as tk
from tkinter import messagebox
import socket

HOST = "127.0.0.1"
PORT = 9999

class RPPClient:
    def __init__(self, root):
        self.root = root
        self.root.title("RPP Online Game - Socket Version")
        self.root.geometry("500x600")
        self.root.configure(bg="white")

        # Socket client
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.client.connect((HOST, PORT))

        # Điểm số
        self.user_score = 0
        self.server_score = 0

        self.setup_ui()

    def setup_ui(self):
        self.title_label = tk.Label(
            self.root,
            text="RPP ONLINE GAME (SOCKET)",
            font=("Helvetica", 22, "bold"),
            bg="white",
            fg="#0056b3",
            pady=20
        )
        self.title_label.pack()

        self.score_label = tk.Label(
            self.root,
            text="Bạn: 0  |  Server: 0",
            font=("Helvetica", 16),
            bg="white",
            fg="#0056b3"
        )
        self.score_label.pack(pady=10)

        self.result_label = tk.Label(
            self.root,
            text="Hãy chọn Búa, Kéo hoặc Bao",
            font=("Helvetica", 14, "italic"),
            bg="white",
            fg="#666",
            pady=20
        )
        self.result_label.pack()

        btn_frame = tk.Frame(self.root, bg="white")
        btn_frame.pack(pady=30)

        buttons = [("Búa", "Rock"), ("Kéo", "Scissors"), ("Bao", "Paper")]
        for text, val in buttons:
            btn = tk.Button(
                btn_frame,
                text=text,
                width=10,
                height=2,
                font=("Helvetica", 12, "bold"),
                bg="#e7f1ff",
                fg="#0056b3",
                command=lambda v=val: self.play(v)
            )
            btn.pack(side=tk.LEFT, padx=10)

    def play(self, choice):
        try:
            # Gửi lựa chọn lên server
            self.client.sendall(choice.encode())

            # Nhận kết quả từ server
            data = self.client.recv(1024).decode()
            user, server, result = data.split(",")

            trans = {"Rock": "Búa", "Paper": "Bao", "Scissors": "Kéo"}

            self.result_label.config(
                text=f"Bạn chọn {trans[user]} - Server chọn {trans[server]}"
            )

            if result == "BẠN THẮNG":
                self.user_score += 1
                messagebox.showinfo("Kết quả", "🎉 Bạn thắng!")
            elif result == "BẠN THUA":
                self.server_score += 1
                messagebox.showwarning("Kết quả", "😢 Bạn thua!")
            else:
                messagebox.showinfo("Kết quả", "😐 Hòa!")

            self.score_label.config(
                text=f"Bạn: {self.user_score}  |  Server: {self.server_score}"
            )

        except:
            messagebox.showerror("Lỗi", "Không kết nối được Server")

if __name__ == "__main__":
    root = tk.Tk()
    app = RPPClient(root)
    root.mainloop()
